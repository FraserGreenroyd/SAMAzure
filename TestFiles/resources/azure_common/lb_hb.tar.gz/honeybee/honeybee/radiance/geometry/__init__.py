"""Radiance Geometry.

In Radiance manual geometries are named as Surfaces.
Read more at: http://radsite.lbl.gov/radiance/refer/ray.html#Surfaces
"""
