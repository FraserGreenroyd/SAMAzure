"""Radiance annual daylight recipes."""
