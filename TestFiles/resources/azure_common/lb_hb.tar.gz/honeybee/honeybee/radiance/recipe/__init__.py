"""Radiance Recipes.

Each recipe supports a commonly used radiance workflow.
"""
