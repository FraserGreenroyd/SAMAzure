"""Annual radiation recipes."""
