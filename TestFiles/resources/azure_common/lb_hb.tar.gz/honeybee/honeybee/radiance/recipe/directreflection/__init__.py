"""Recipes for direct reflection modeling."""
