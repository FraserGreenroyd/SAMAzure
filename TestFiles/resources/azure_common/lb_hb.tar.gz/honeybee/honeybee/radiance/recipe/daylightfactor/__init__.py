"""Daylight factor recipes."""
