"""Radiance daylight coefficient recipes.

Daylight coefficient recipes support both grid-based and image-based analysis.
"""
