
class HBObject(object):
    """Base class for Honeybee Zone and Surface."""

    @property
    def isHBObject(self):
        """Return True."""
        return True
