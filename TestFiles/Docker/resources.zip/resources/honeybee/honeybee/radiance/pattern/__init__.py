"""Radiance Patterns.

Patterns are used to modify the reflectance of materials.

See http://radsite.lbl.gov/radiance/refer/ray.html#Patterns
"""
