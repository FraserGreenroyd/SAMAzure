"""Radiance Mixtures.

A mixture is a blend of one or more materials or textures and patterns. Blended materials
should not be light source types or virtual source types.
"""
