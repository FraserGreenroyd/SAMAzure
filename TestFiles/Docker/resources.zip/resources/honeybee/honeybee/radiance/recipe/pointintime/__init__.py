"""Point-in-time recipes."""
