"""Honeybee skies."""
