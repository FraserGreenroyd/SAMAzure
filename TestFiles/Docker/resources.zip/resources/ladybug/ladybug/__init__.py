import sys

# This is a variable to check if the library is a [+] library.
setattr(sys.modules[__name__], 'isplus', False)
