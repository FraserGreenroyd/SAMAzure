#ifndef lint
static const char	RCSid[] = "$Id: addobjnotify.c,v 3.3 2003/02/25 02:47:21 greg Exp $";
#endif
/*
 * Dummy declaration of addobjnotify[]
 */

#include "copyright.h"

void  (*addobjnotify[1])() = {0};
