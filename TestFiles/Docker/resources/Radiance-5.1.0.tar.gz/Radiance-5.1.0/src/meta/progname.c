#ifndef lint
static const char	RCSid[] = "$Id: progname.c,v 1.1 2003/02/22 02:07:26 greg Exp $";
#endif
/*
 *  progname.c - definition of progname for library.
 *
 *     2/24/86
 */


char  *progname = "meta";
